// #include "malloc.h"
#include "malloc.h"

int		main()
{
	char	*str = NULL;
	int		tmp;

	tmp = 0;
	for (int i = 0; i < 8000; ++i)
	{
		tmp += i;
		str = realloc(str, i);
		ft_putnbr(tmp);
		ft_putchar('\n');
	}
	ft_putendl("END ALLOC");
	show_alloc_mem();
	return (0);
}