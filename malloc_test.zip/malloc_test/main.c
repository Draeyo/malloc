// #include "malloc.h"
#include "malloc.h"

int		main()
{
	char	*str = NULL;
	char	*str2 = NULL;
	int		tmp;

	tmp = 0;
	for (int i = 0; i < 110; ++i)
	{
		tmp += i;
		str = malloc(SMALL_SIZE - 1);
		str2 = realloc(str, SMALL_SIZE - 2);
	}
	ft_putendl("END ALLOC");
	show_alloc_mem();
	return (0);
}