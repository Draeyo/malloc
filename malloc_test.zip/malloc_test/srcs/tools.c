#include "malloc.h"

void	*eco_search(size_t size, size_t type)
{
	t_zone	*tmp;
	t_alloc	*mem;

	tmp = !type ? g_mem->tiny : g_mem->small;
	while (tmp)
	{
		mem = tmp ? (void*)tmp + sizeof(t_zone) : NULL;
		while (mem)
		{
			if (mem->free)
			{
				mem->free = 0;
				mem->size = size;
				return ((void*)mem + sizeof(t_alloc));
			}
			mem = mem->next;
		}
		tmp = tmp->next;
	}
	return (NULL);
}

void	*eco_alloc(size_t size, size_t type)
{
	void	*tmp;

	tmp = NULL;
	if (!type && size <= TINY_SIZE && g_mem->tiny->last)
		tmp = eco_search(size, 0);
	else if (type && size <= SMALL_SIZE && g_mem->small->last)
		tmp = eco_search(size, 1);
	return ((void*)tmp);
}