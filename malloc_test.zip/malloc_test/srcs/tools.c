#include "malloc.h"


static void		*find_large(void *ptr)
{
	t_zone 		*tmp;
	void		*ret;

	tmp = g_mem->large;
	ret = NULL;
	while (tmp)
	{
		if (((void*)tmp + sizeof(t_zone)) == ptr)
			return (tmp);
		tmp = tmp->next;
	}
	return (NULL);
}

static void		*find_by_type(t_zone *zone, void *ptr)
{
	t_zone 		*tmp;
	t_alloc		*mem;

	tmp = zone;
	mem = NULL;
	while (tmp && tmp->next)
	{
		mem = tmp->start ? tmp->start : NULL;
		while (mem && mem->next)
		{
			if ((void*)mem->data == ptr && !mem->free)
				return (mem);
			mem = mem->next;
		}
		tmp = tmp->next;
	}
	return (NULL);
}

void			*find_alloc(void *ptr)
{
	void		*ret;

	ret = NULL;
	if ((ret = find_by_type(g_mem->tiny, ptr)) != NULL)
		return (ret);
	if ((ret = find_by_type(g_mem->small, ptr)) != NULL)
		return (ret);
	if ((ret = find_large(ptr)) != NULL)
		return (ret);
	return (NULL);
}

void		*eco_search(size_t size, size_t type)
{
	t_zone	*tmp;
	t_alloc	*mem;

	tmp = !type ? g_mem->tiny : g_mem->small;
	while (tmp && tmp->next)
	{
		mem = tmp ? (void*)tmp + sizeof(t_zone) : NULL;
		while (mem && mem->next)
		{
			if (mem->free && mem->size <= size)
			{
				mem->free = 0;
				mem->size = size;
				return ((void*)mem);
			}
			mem = mem->next;
		}
		tmp = tmp->next;
	}
	return (NULL);
}

void	*eco_alloc(size_t size, size_t type)
{
	void	*tmp;

	tmp = NULL;
	if (!type && size <= TINY_SIZE && g_mem->tiny->last)
		tmp = eco_search(size, 0);
	else if (type && size <= SMALL_SIZE && g_mem->small->last)
		tmp = eco_search(size, 1);
	return ((void*)tmp);
}