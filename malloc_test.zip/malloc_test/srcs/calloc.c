#include "malloc.h"

void	*calloc(size_t count, size_t size)
{
	void	*ptr;

	// ft_putendl("CALLOC START");
	if ((ptr = malloc(count * size)) == NULL)
		return (NULL);
	ft_memset(ptr, 0, count * size);
	// ft_putendl("CALLOC END");
	return (ptr);
}
