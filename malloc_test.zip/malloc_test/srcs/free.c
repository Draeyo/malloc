#include "malloc.h"

void	free(void *ptr)
{
	// t_alloc		*tmp;

	// tmp = NULL;
	// if (!ptr)
	// 	return ;
	// if ((tmp = find_large(ptr)) == NULL)
	// if ((tmp = find_alloc(ptr)) == NULL)
	// 	return ;
	(void)ptr;
	return ;
}