#include "malloc.h"

void	*realloc(void *ptr, size_t size)
{
	void	*ret;

	// ft_putendl("+R+");
	size = ft_mem_padding(size);
	ret = malloc(size);
	if (ptr != NULL)
		ft_memmove(ret, ptr, size);
	// ft_putendl("++R++");
	return (ret);
}