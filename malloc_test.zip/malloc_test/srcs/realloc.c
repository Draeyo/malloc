#include "malloc.h"

static void		*resize_alloc(t_alloc *mem, size_t size)
{
	void	*ret;

	ret = NULL;
	if ((ret = malloc(size)) == NULL)
		return (NULL);
	ft_memmove(ret, mem->data, mem->size);
	mem->free = 1;
	return (ret);
}

static void		*re_alloc(void *ptr, size_t size)
{
	t_alloc		*tmp;
	void		*ret;

	tmp = NULL;
	ret = NULL;
	if (ptr == NULL)
		return (malloc(size));
	if ((tmp = find_alloc(ptr)) == NULL || (tmp && tmp->free))
	{
		// DEBUG
		if (tmp == NULL)
			ft_putendl("TMP NULL");
		if (tmp && tmp->free)
			ft_putendl("TMP FREE");
		ft_putstr("CHECK PTR: ");
		ft_print_mem(ptr);
		ft_putchar('\n');
		// DEBUG
		return (NULL);
	}
	if ((tmp != NULL && size == 0) || tmp->size > size)
	{
		//
		ft_putendl("POTENTIAL 0 SIZE REALLOC");
		//
		if ((ret = malloc(size)) != NULL)
			tmp->free = 1;
		return (ret);
	}
	// join free
	return (resize_alloc(tmp, size));
}

void			*realloc(void *ptr, size_t size)
{
	void	*ret;

	//
	ft_putstr("PTR: ");
	ft_print_mem(ptr);
	ft_putchar('\n');
	//
	size = ft_mem_padding(size);
	if ((ret = re_alloc(ptr, size)) == NULL)
	{
		//
		ft_putstr("RET NULL : ");
		ft_print_mem(ptr);
		ft_putchar('\n');
		//
		return (ptr);
	}
	//
	ft_putstr("RET OK : ");
	ft_print_mem(ret);
	ft_putchar('\n');
	//
	return (ret);
}