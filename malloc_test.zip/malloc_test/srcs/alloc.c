#include "malloc.h"

static t_zone	*alloc_zone(size_t size)
{
	t_zone		*new;

	new = NULL;
	if ((new = mmap(0, size, PROT, FLAGS, -1, 0)) == MAP_FAILED)
		return (NULL);
	new->start = (void*)new + sizeof(t_zone);
	new->end = new->start + size;
	new->last = NULL;
	new->next_safe = new->start;
	new->next = NULL;
	new->size = size;
	return (new);
}

static void		*alloc_mem(size_t size)
{
	t_alloc 	*new;

	new = NULL;
	if (!g_mem->tiny_last)
		return (NULL);
	new = g_mem->tiny_last->next_safe;
	new->size = size;
	new->next = (void*)new + sizeof(t_alloc) + size;
	new->free = 0;
	new->data = (void*)new + sizeof(t_alloc);
	g_mem->tiny_last->next_safe += sizeof(t_alloc) + size;
	g_mem->tiny_last->last = new + sizeof(t_alloc);
	return (new);
}

void			*alloc_tiny(size_t size)
{
	t_alloc 	*new_tiny;
	t_alloc 	*tmp;

	tmp = NULL;
	if (!g_mem->tiny)
	{
		g_mem->tiny = alloc_zone(TINY_ZONE_SIZE);
		g_mem->tiny_last = g_mem->tiny;
	}
	if ((long)g_mem->tiny_last->last + (long)size > (long)g_mem->tiny_last->end)
	{
		ft_putendl("NEW_ZONE");
		g_mem->tiny_last->next = alloc_zone(TINY_ZONE_SIZE);
		g_mem->tiny_last = g_mem->tiny_last->next;
	}
	if ((new_tiny = eco_alloc(size, 0)) == NULL)
		new_tiny = alloc_mem(size);
	g_mem->tiny_last->last = (void*)new_tiny;
	return ((void*)new_tiny + sizeof(t_alloc));
}

void	*alloc_small(size_t size)
{
	t_alloc 	*new_small;
	t_alloc		*tmp;

	tmp = NULL;
	if (!g_mem->small)
	{
		g_mem->small = alloc_zone(SMALL_ZONE_SIZE);
		g_mem->small_last = g_mem->small;
	}
	if (g_mem->small_last->last + size > g_mem->small_last->end)
	{
		g_mem->small_last->next = alloc_zone(SMALL_ZONE_SIZE);
		g_mem->small_last = g_mem->small_last->next;
	}
	if ((new_small = eco_alloc(size, 1)) == NULL)
		new_small = alloc_mem(size);
	g_mem->small_last->last = (void*)new_small;
	return ((void*)new_small + sizeof(t_alloc));

}

void	*alloc_large(size_t size)
{
	t_zone 	*new_large;

	new_large = alloc_zone(size);
	if (!g_mem->large)
	{
		g_mem->large = new_large;
		g_mem->large_last = g_mem->large;
	}
	else
	{
		g_mem->large_last->next = new_large;
		g_mem->large_last = g_mem->large_last->next;
	}
	return ((void*)new_large + sizeof(t_zone));
}