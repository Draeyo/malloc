#include "malloc.h"

static t_zone	*alloc_zone(size_t size)
{
	t_zone		*new;

	new = NULL;
	if ((new = mmap(0, size, PROT, FLAGS, -1, 0)) == MAP_FAILED)
		return (NULL);
	new->start = (void*)new + sizeof(t_zone);
	new->end = (void*)new->start + size;
	new->last = NULL;
	new->next_safe = (void*)new->start;
	new->next = NULL;
	new->size = size;
	return (new);
}

static void		*alloc_mem_tiny(size_t size)
{
	t_alloc 	*new;
	t_alloc		*tmp;

	new = NULL;
	tmp = NULL;
	if (!g_mem->tiny_last)
		return (NULL);
	new = (void*)g_mem->tiny_last->next_safe;
	new->size = size;
	// new->next = (void*)new + sizeof(t_alloc) + size;
	new->next = NULL;
	new->free = 0;
	new->data = (void*)new + sizeof(t_alloc);
	if (new->data + size + (TINY_SIZE + sizeof(t_alloc)) < g_mem->tiny_last->end)
		g_mem->tiny_last->next_safe = new->data + size;
	else
		g_mem->tiny_last->next_safe = NULL;
	if (g_mem->tiny_last->last != NULL)
	{
		tmp = g_mem->tiny_last->last;
		tmp->next = new;
	}
	g_mem->tiny_last->last = new;
	return (new);
}

static void		*alloc_mem_small(size_t size)
{
	t_alloc 	*new;
	t_alloc		*tmp;

	new = NULL;
	tmp = NULL;
	if (!g_mem->small_last)
		return (NULL);
	new = (void*)g_mem->small_last->next_safe;
	// ft_print_mem(g_mem->small_last->next_safe);
	// ft_putchar('\n');
	new->size = size;
	new->next = NULL;
	new->free = 0;
	new->data = (void*)new + sizeof(t_alloc);
	if (new->data + size + (SMALL_SIZE + sizeof(t_alloc)) < g_mem->small_last->end)
		g_mem->small_last->next_safe = new->data + size;
	else
		g_mem->small_last->next_safe = NULL;
	if (g_mem->small_last->last != NULL)
	{
		tmp = g_mem->small_last->last;
		tmp->next = new;
	}
	g_mem->small_last->last = new;
	return (new);
}

static void		*alloc_mem_large(size_t size)
{
	t_alloc 	*new;
	t_alloc		*tmp;

	new = NULL;
	tmp = NULL;
	if (!g_mem->large_last)
		return (NULL);
	new = (void*)g_mem->large_last + sizeof(t_zone);
	new->size = size;
	new->next = NULL;
	new->free = 0;
	new->data = (void*)new + sizeof(t_alloc);
	g_mem->large_last->next_safe = NULL;
	if (g_mem->large_last->last != NULL)
	{
		tmp = g_mem->large_last->last;
		tmp->next = new;
	}
	g_mem->large_last->last = new;
	return (new);
}

void			*alloc_tiny(size_t size)
{
	t_alloc 	*new_tiny;
	t_alloc 	*tmp;

	tmp = NULL;
	if (!g_mem->tiny)
	{
		g_mem->tiny = alloc_zone(TINY_ZONE_SIZE);
		g_mem->tiny_last = g_mem->tiny;
	}
	// verifier plutot si il reste de la place dans la zone actuelle
	//if ((void*)g_mem->tiny_last->last + size + sizeof(t_alloc) >= g_mem->tiny_last->end)
	if (!g_mem->tiny_last->next_safe || (g_mem->tiny_last->next_safe + size + INFO_SIZE >= g_mem->tiny_last->end))
	{
		g_mem->tiny_last->next = alloc_zone(TINY_ZONE_SIZE);
		g_mem->tiny_last = g_mem->tiny_last->next;
	}
	if ((new_tiny = eco_alloc(size, 0)) == NULL)
		new_tiny = alloc_mem_tiny(size);
	g_mem->tiny_last->last = (void*)new_tiny;
	return ((void*)new_tiny + sizeof(t_alloc));
}

void	*alloc_small(size_t size)
{
	t_alloc 	*new_small;
	t_alloc		*tmp;

	tmp = NULL;
	if (!g_mem->small)
	{
		g_mem->small = alloc_zone(SMALL_ZONE_SIZE);
		g_mem->small_last = g_mem->small;
	}
	// verifier plutot si il reste de la place dans la zone actuelle
	// if ((void*)g_mem->small_last->last + size + sizeof(t_alloc) >= g_mem->small_last->end)
	if (!g_mem->small_last->next_safe || (g_mem->small_last->next_safe + size + INFO_SIZE >= g_mem->small_last->end))
	{
		g_mem->small_last->next = alloc_zone(SMALL_ZONE_SIZE);
		g_mem->small_last = g_mem->small_last->next;
	}
	if ((new_small = eco_alloc(size, 1)) == NULL)
		new_small = alloc_mem_small(size);
	g_mem->small_last->last = (void*)new_small;
	return ((void*)new_small + sizeof(t_alloc));

}

void	*alloc_large(size_t size)
{
	t_alloc		*new_large;

	new_large = NULL;
	if (!g_mem->large)
	{
		g_mem->large = alloc_zone(size + sizeof(t_zone));
		g_mem->large_last = g_mem->large;
	}
	else
	{
		g_mem->large_last->next = alloc_zone(size + sizeof(t_zone));
		g_mem->large_last = g_mem->large_last->next;
	}
	new_large = alloc_mem_large(size);
	g_mem->large_last->last = (void*)new_large;
	return ((void*)new_large + sizeof(t_alloc));
}