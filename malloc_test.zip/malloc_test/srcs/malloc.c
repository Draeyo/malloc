#include "malloc.h"
#include <signal.h>
#include <execinfo.h>

t_overall *g_mem = NULL;

static void		init_glob()
{
	g_mem = mmap(0, PAGE_SIZE, PROT, FLAGS, -1, 0);
	g_mem->tiny = NULL;
	g_mem->tiny_last = NULL;
	g_mem->small = NULL;
	g_mem->small_last = NULL;
	g_mem->large = NULL;
	g_mem->large_last = NULL;
}

void	print_trace(int	nb)
{
	void *array[10];
	size_t size;
	char **strings;
	size_t i;

	size = backtrace(array, 10);
	strings = backtrace_symbols(array, size);

	(void)nb;
	for (i = 0; i < size; i++)
		ft_putendl(strings[i]);

	ft_putstr("SIGNAL : ");
	ft_putnbr(nb);
	ft_putchar('\n');
	free(strings);
	//perror(NULL);
	exit(1);
}

size_t	ft_mem_padding(size_t size)
{
	size_t ret;

	ret = 0;
	while (ret < size)
		ret += 16;
	return (ret);
}

void	*malloc(size_t size)
{
	void	*ret;

	// ft_putnbr(size);
	// ft_putendl("+");
	// for (int i = 0; i < 18; ++i)
		// signal(i, &print_trace);
	ret = NULL;
	if (!g_mem)
		init_glob();
	size = ft_mem_padding(size);
	if (size <= 0 || size >= SIZE_MAX)
		return (NULL);
	else if (size <= TINY_SIZE)
		ret = alloc_tiny(size);
	else if (size <= SMALL_SIZE)
		ret = alloc_small(size);
	else
		ret = alloc_large(size);
	if (ret == MAP_FAILED)
		return (NULL);
	// show_alloc_mem();
	// ft_putendl("+++");
//	set_info(size, ret);
	// ft_putendl("NEW_ALLOC");
	return (ret);
}